ZYVRO SOCIAL BUNDLE

Files inside this ZIP:
- index.html: game page with a visible Social shortcut
- social.html: Social page (Rank, Friends, Private Chat, Room Chat)

Deployment on GitHub Pages:
1. Back up your current index.html and social.html.
2. Upload both files from this ZIP to the repository root, replacing files with the same names.
3. Keep auth.html and profile_premium_v2.html unchanged.
4. Open https://mahendrajatava874-blip.github.io/Zyvro/index.html and tap Social.

Testing note: inline JavaScript syntax was checked with Node.js. This bundle has NOT been tested against your live Supabase project. The social tables' RLS policies and permissions must allow the intended signed-in user operations; if not, the page will show a database error.

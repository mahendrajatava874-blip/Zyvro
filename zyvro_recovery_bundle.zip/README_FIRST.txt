Zyvro stable recovery bundle

This index.html is based on the complete earlier social bundle, not the truncated index (7). It preserves the Supabase login gate and Profile/Social/Logout controls, and uses the complete local 30-second virtual practice game so the timer, selections, bet confirmation, results and Small/Big history do not depend on the currently empty shared-round table. History is capped at 10 entries.

Important: this is a recovery build for the game UI and local virtual practice. It does NOT provide shared results/wallet settlement across different users. The shared RPC flow must be repaired and tested separately before re-enabling multiplayer shared rounds.

Install: back up repository index.html, upload this file to the repository root, rename it index.html, commit changes, then open the GitHub Pages URL with a cache-busting query such as ?v=20261015b or refresh the page. Keep social.html, auth.html, and profile_premium_v2.html unchanged.
